# MFCS PRD1 — Schema Exploration Findings

Connection verified via OAuth2 client_credentials (Oracle IDCS). Every GET was capped at **limit=1**.

**34 endpoints returned live data** and now have schemas under `schemas/schema/`. The remaining GETs are blocked server-side or need input, detailed below.

## ✅ Working — schema captured (34 endpoints)

| Fields | Endpoint | Folder |
|---:|---|---|
| 211 | Get Item Details for All or Provided Items | Items - Item Definition |
| 115 | Get Store Details | Organizational Hierarchy - Stores |
| 98 | Get Item Location Details | Items - Item Definition |
| 75 | Get Warehouse Details | Organizational Hierarchy - Warehouses |
| 50 | Get Basic Item Details | Items - Item Definition |
| 50 | Get Item Reference Items | Items - Item Definition |
| 34 | Get Item Locations for Omnichannel | Items - Item Definition |
| 31 | Get Warehouse Details for Omnichannel | Organizational Hierarchy - Warehouses |
| 29 | Get Store Details for Omnichannel | Organizational Hierarchy - Stores |
| 24 | getStatus | Untagged |
| 18 | Get Item Location Price Details | Items - Item Definition |
| 18 | Get Organizational Hirerachy | Organizational Hierarchy |
| 16 | Get Item Available Inventory at Customer Orderable Locations | Inventory |
| 16 | Get Organizational Hierarchy Relationships | Organizational Hierarchy |
| 15 | Get Warehouse Available Inventory | Inventory |
| 15 | Get Merchandise Hierarchy for Omnichannel | Merchandise Hierarchy |
| 14 | Get Codes and Descriptions for All or Provided Code Type | Administration - Operations |
| 14 | Get Store Available Inventory | Inventory |
| 14 | Get Item Differentiator (Dimension) Values | Items - Item Definition |
| 13 | Get Item Differentiator (Dimension) Types | Items - Item Definition |
| 13 | Get Organizational Hierarchy below Level for Omnichannel | Organizational Hierarchy |
| 12 | Get Differentiator Groups | Items - Item Foundation |
| 12 | Get Differentiators | Items - Item Foundation |
| 11 | Get Brands | Items - Item Foundation |
| 10 | Get Integration Service Last Data Refresh And Latest Data Update Time | Administration - Operations |
| 7 | Get Webhook Configuration and Status | Administration - Operations |
| 7 | Get Value Added Tax (VAT) Definitions | Financials - Taxes |
| 7 | Get Item Future Inventory | Inventory |
| 7 | Get Seasons and Phases | Items - Item Foundation |
| 7 | Get Related Items | Items - Related Items |
| 4 | Get 4-5-4 Calendar | Administration - Operations |
| 4 | Get Channels | Foundation |
| 3 | Get Batch Run Status | Administration - Operations |
| 2 | Get Banners | Foundation |

## ⛔ Not enabled in this environment (35 endpoints)

Oracle returns HTTP 400: *"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load."* These need enabling on the Merchandising side before they return data:

- Administration - Operations :: Get Fiscal Calendar
- Foundation - Partners :: Get Partners
- Foundation - Suppliers :: Get Supplier Details
- Foundation - Suppliers :: Get Supplier Details for Provided Supplier
- Global Tax Solution - Tax Services :: Get Tax Location Item
- Global Tax Solution - Tax Services :: Get Tax Locations
- Global Tax Solution - Tax Services :: Get Tax group rule
- Inventory - Returns to Vendor :: Get Returns to Vendor
- Inventory - Shipments and Receipts :: Get Receiver Unit Adjustment
- Inventory - Shipments and Receipts :: Get Stock Order Shipment Created in Merchandising
- Inventory - Transfers and Allocations :: Get Allocation Details for Provided Allocation
- Inventory - Transfers and Allocations :: Get Allocations
- Inventory - Transfers and Allocations :: Get Transfer
- Inventory - Transfers and Allocations :: Get Transfer Details for Provided Transfer
- Inventory - Work Orders :: Get Work Order In
- Inventory - Work Orders :: Get Work Order In Details for Provided Work Order
- Inventory - Work Orders :: Get Work Order Out
- Inventory - Work Orders :: Get Work Order Out Details for Provided Work Order
- Items - Item Definition :: Get Item VAT Details
- Items - Item Foundation :: Get Differentiator Details
- Items - Item Foundation :: Get Differentiator Types
- Items - Item Foundation :: Get UDA Details
- Items - Item Foundation :: Get UDA Details for Provided UDA
- Merchandise Hierarchy :: Get Class Details for Provided Class
- Merchandise Hierarchy :: Get Classes
- Merchandise Hierarchy :: Get Department Details for Provided Department
- Merchandise Hierarchy :: Get Departments
- Merchandise Hierarchy :: Get Division Details for Provided Division
- Merchandise Hierarchy :: Get Divisions
- Merchandise Hierarchy :: Get Group for Provided Group
- Merchandise Hierarchy :: Get Groups
- Merchandise Hierarchy :: Get Subclass Details for Provided Subclass
- Merchandise Hierarchy :: Get Subclasses
- Purchase Orders :: Get Purchase Order Details
- Purchase Orders :: Get Purchase Order Details by Order Number

## ⚠️ Needs a query parameter (2 endpoints)

- **Get ReST Service Status** — {"status":"VALIDATION_ERROR","message":"Error found in validation of input payload","validationErrors":[{"error":"Query Parameter xCorrelationId is mandatory","field":"arg1","input
- **Get Item Location Weekly Sales** — {"status":"ERROR","message":"Atleast one of the following query parameter should be provided - eowDate, location, item.","error":{"status":400,"message":"Atleast one of the followi

## 🔎 ID lookups needing a valid id

404 (harvested id didn't match a live record): Get Store Details for Provided Store, Get Warehouse Details for Provided Warehouse

Skipped (no id could be harvested — supply manually): Get Partner Details for Provided Partner, Get Return to Vendor Details for Provided RTV, Get Item Details for Provided Item, Get Item VAT Details by Item Number, Get Differentiator Details for Provided Differentiator, Get Differentiator Type Details for Provided Type, Get Differentiators for Provided Group, Get Organizational Hierarchy for Provided Level, Get Organizational Hierarchy for Provided Level and Hirerachy Identifier, getExternalGrammar

## Other

- Get Item Image Details — `error`
- getWadl — `http_406`
- ping — `http_204`
