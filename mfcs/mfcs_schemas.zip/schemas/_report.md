# MFCS Schema Exploration Report

Collection: **PRD1 - John's Production Swagger**
Endpoints probed: **101** (limit=1 record each)

## Status summary

- `http_400`: 50
- `ok`: 34
- `skipped_needs_id`: 10
- `http_404`: 4
- `error`: 1
- `http_406`: 1
- `http_204`: 1

## Administration - Operations

### Get 4-5-4 Calendar  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/administration/operations/calendar`
- Fields discovered: 4  (schema: `schema/Administration_Operations_Get_4_5_4_Calendar.json`)

### Get Batch Run Status  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/administration/operations/batchRunStatus`
- Fields discovered: 3  (schema: `schema/Administration_Operations_Get_Batch_Run_Status.json`)

### Get Codes and Descriptions for All or Provided Code Type  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/administration/operations/codes`
- Params: `{'limit': 1}`
- Fields discovered: 14  (schema: `schema/Administration_Operations_Get_Codes_and_Descriptions_for_All_or_Provided_Code_Type.json`)

### Get Fiscal Calendar  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/administration/fiscalCalendar`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Administration_Operations_Get_Fiscal_Calendar.json`)

### Get Integration Service Last Data Refresh And Latest Data Update Time  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/omnichannel/refreshdate`
- Fields discovered: 10  (schema: `schema/Administration_Operations_Get_Integration_Service_Last_Data_Refresh_And_Latest_Data_Update_Time.json`)

### Get ReST Service Status  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/administration/operations/restService/status`
- Params: `{'limit': 1}`
- Preview: `{"status":"VALIDATION_ERROR","message":"Error found in validation of input payload","validationErrors":[{"error":"Query Parameter xCorrelationId is mandatory","field":"arg1","inputValue":null}]}`
- Fields discovered: 6  (schema: `schema/Administration_Operations_Get_ReST_Service_Status.json`)

### Get Webhook Configuration and Status  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/administration/operations/webhooks`
- Params: `{'limit': 1}`
- Fields discovered: 7  (schema: `schema/Administration_Operations_Get_Webhook_Configuration_and_Status.json`)

## Financials - Taxes

### Get Value Added Tax (VAT) Definitions  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/vat`
- Params: `{'limit': 1}`
- Fields discovered: 7  (schema: `schema/Financials_Taxes_Get_Value_Added_Tax_VAT_Definitions.json`)

## Foundation

### Get Banners  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/banners`
- Fields discovered: 2  (schema: `schema/Foundation_Get_Banners.json`)

### Get Channels  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/channels`
- Fields discovered: 4  (schema: `schema/Foundation_Get_Channels.json`)

## Foundation - Partners

### Get Partner Details for Provided Partner  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/partner/:partnerId`
- Note: needs value(s) for path var(s): partnerId

### Get Partners  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/partner`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Foundation_Partners_Get_Partners.json`)

## Foundation - Suppliers

### Get Supplier Details  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/supplier`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Foundation_Suppliers_Get_Supplier_Details.json`)

### Get Supplier Details for Provided Supplier  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/supplier/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Foundation_Suppliers_Get_Supplier_Details_for_Provided_Supplier.json`)

### Get Supplier Details for Provided Supplier  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/supplier/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Foundation_Suppliers_Get_Supplier_Details_for_Provided_Supplier.json`)

## Global Tax Solution - Tax Services

### Get Tax Location Item  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/taxLocationItem`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Global_Tax_Solution_Tax_Services_Get_Tax_Location_Item.json`)

### Get Tax Locations  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/taxLocation`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Global_Tax_Solution_Tax_Services_Get_Tax_Locations.json`)

### Get Tax group rule  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/taxGroupRule`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Global_Tax_Solution_Tax_Services_Get_Tax_group_rule.json`)

## Inventory

### Get Item Available Inventory at Customer Orderable Locations  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/available`
- Params: `{'limit': 1}`
- Fields discovered: 16  (schema: `schema/Inventory_Get_Item_Available_Inventory_at_Customer_Orderable_Locations.json`)

### Get Item Future Inventory  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/omnichannel/inventory/futureinventory`
- Params: `{'limit': 1}`
- Fields discovered: 7  (schema: `schema/Inventory_Get_Item_Future_Inventory.json`)

### Get Store Available Inventory  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/omnichannel/inventory/store`
- Params: `{'limit': 1}`
- Fields discovered: 14  (schema: `schema/Inventory_Get_Store_Available_Inventory.json`)

### Get Warehouse Available Inventory  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/omnichannel/inventory/warehouse`
- Params: `{'limit': 1}`
- Fields discovered: 15  (schema: `schema/Inventory_Get_Warehouse_Available_Inventory.json`)

## Inventory - Returns to Vendor

### Get Return to Vendor Details for Provided RTV  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/rtv/:rtvOrderNo`
- Note: needs value(s) for path var(s): rtvOrderNo

### Get Returns to Vendor  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/rtv`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Returns_to_Vendor_Get_Returns_to_Vendor.json`)

## Inventory - Shipments and Receipts

### Get Receiver Unit Adjustment  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/receiverunitadj`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Shipments_and_Receipts_Get_Receiver_Unit_Adjustment.json`)

### Get Stock Order Shipment Created in Merchandising  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/shipmentsAndReceipts/stockOrder/shipment`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Shipments_and_Receipts_Get_Stock_Order_Shipment_Created_in_Merchandising.json`)

## Inventory - Transfers and Allocations

### Get Allocation Details for Provided Allocation  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/allocation/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Transfers_and_Allocations_Get_Allocation_Details_for_Provided_Allocation.json`)

### Get Allocation Details for Provided Allocation  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/allocation/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Transfers_and_Allocations_Get_Allocation_Details_for_Provided_Allocation.json`)

### Get Allocations  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/allocation`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Transfers_and_Allocations_Get_Allocations.json`)

### Get Transfer  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/transfer`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Transfers_and_Allocations_Get_Transfer.json`)

### Get Transfer Details for Provided Transfer  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/transfer/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Transfers_and_Allocations_Get_Transfer_Details_for_Provided_Transfer.json`)

### Get Transfer Details for Provided Transfer  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/transfer/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Transfers_and_Allocations_Get_Transfer_Details_for_Provided_Transfer.json`)

## Inventory - Work Orders

### Get Work Order In  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/woin`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Work_Orders_Get_Work_Order_In.json`)

### Get Work Order In Details for Provided Work Order  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/woin/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Work_Orders_Get_Work_Order_In_Details_for_Provided_Work_Order.json`)

### Get Work Order In Details for Provided Work Order  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/woin/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Work_Orders_Get_Work_Order_In_Details_for_Provided_Work_Order.json`)

### Get Work Order Out  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/woout`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Work_Orders_Get_Work_Order_Out.json`)

### Get Work Order Out Details for Provided Work Order  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/woout/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Work_Orders_Get_Work_Order_Out_Details_for_Provided_Work_Order.json`)

### Get Work Order Out Details for Provided Work Order  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/inventory/woout/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Inventory_Work_Orders_Get_Work_Order_Out_Details_for_Provided_Work_Order.json`)

## Items - Item Definition

### Get Basic Item Details  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/item`
- Params: `{'limit': 1}`
- Fields discovered: 50  (schema: `schema/Items_Item_Definition_Get_Basic_Item_Details.json`)

### Get Item Details for All or Provided Items  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/item`
- Params: `{'limit': 1}`
- Fields discovered: 211  (schema: `schema/Items_Item_Definition_Get_Item_Details_for_All_or_Provided_Items.json`)

### Get Item Details for Provided Item  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/item/:itemId`
- Note: needs value(s) for path var(s): itemId

### Get Item Differentiator (Dimension) Types  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/item/dimensiontype`
- Params: `{'limit': 1}`
- Fields discovered: 13  (schema: `schema/Items_Item_Definition_Get_Item_Differentiator_Dimension_Types.json`)

### Get Item Differentiator (Dimension) Values  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/item/dimensionvalue`
- Params: `{'limit': 1}`
- Fields discovered: 14  (schema: `schema/Items_Item_Definition_Get_Item_Differentiator_Dimension_Values.json`)

### Get Item Image Details  —  `error`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/item/image`
- Params: `{'limit': 1}`

### Get Item Location Details  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/item/location`
- Params: `{'limit': 1}`
- Fields discovered: 98  (schema: `schema/Items_Item_Definition_Get_Item_Location_Details.json`)

### Get Item Location Price Details  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/item/initialprice`
- Params: `{'limit': 1}`
- Fields discovered: 18  (schema: `schema/Items_Item_Definition_Get_Item_Location_Price_Details.json`)

### Get Item Locations for Omnichannel  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/item/itemlocation`
- Params: `{'limit': 1}`
- Fields discovered: 34  (schema: `schema/Items_Item_Definition_Get_Item_Locations_for_Omnichannel.json`)

### Get Item Reference Items  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/item/upc`
- Params: `{'limit': 1}`
- Fields discovered: 50  (schema: `schema/Items_Item_Definition_Get_Item_Reference_Items.json`)

### Get Item VAT Details  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/item/vat`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Items_Item_Definition_Get_Item_VAT_Details.json`)

### Get Item VAT Details by Item Number  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/item/vat/:item`
- Params: `{'limit': 1}`
- Note: needs value(s) for path var(s): item

## Items - Item Foundation

### Get Brands  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/item/brands`
- Params: `{'limit': 1}`
- Fields discovered: 11  (schema: `schema/Items_Item_Foundation_Get_Brands.json`)

### Get Differentiator Details  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/diffid`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Items_Item_Foundation_Get_Differentiator_Details.json`)

### Get Differentiator Details for Provided Differentiator  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/diffid/:diffId`
- Note: needs value(s) for path var(s): diffId

### Get Differentiator Groups  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/diffgroup`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Items_Item_Foundation_Get_Differentiator_Groups.json`)

### Get Differentiator Groups  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/diff/group`
- Params: `{'limit': 1}`
- Fields discovered: 12  (schema: `schema/Items_Item_Foundation_Get_Differentiator_Groups.json`)

### Get Differentiator Type Details for Provided Type  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/difftype/:diffType`
- Note: needs value(s) for path var(s): diffType

### Get Differentiator Types  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/difftype`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Items_Item_Foundation_Get_Differentiator_Types.json`)

### Get Differentiators  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/diff`
- Params: `{'limit': 1}`
- Fields discovered: 12  (schema: `schema/Items_Item_Foundation_Get_Differentiators.json`)

### Get Differentiators for Provided Group  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/diffgroup/:diffGroupId`
- Note: needs value(s) for path var(s): diffGroupId

### Get Seasons and Phases  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/item/foundation/seasons`
- Params: `{'limit': 1}`
- Fields discovered: 7  (schema: `schema/Items_Item_Foundation_Get_Seasons_and_Phases.json`)

### Get UDA Details  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/uda`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Items_Item_Foundation_Get_UDA_Details.json`)

### Get UDA Details for Provided UDA  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/uda/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Items_Item_Foundation_Get_UDA_Details_for_Provided_UDA.json`)

### Get UDA Details for Provided UDA  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/uda/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Items_Item_Foundation_Get_UDA_Details_for_Provided_UDA.json`)

## Items - Related Items

### Get Related Items  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/item/relateditem`
- Params: `{'limit': 1}`
- Fields discovered: 7  (schema: `schema/Items_Related_Items_Get_Related_Items.json`)

## Merchandise Hierarchy

### Get Class Details for Provided Class  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/class/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Class_Details_for_Provided_Class.json`)

### Get Class Details for Provided Class  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/class/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Class_Details_for_Provided_Class.json`)

### Get Classes  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/class`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Classes.json`)

### Get Department Details for Provided Department  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/deps/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Department_Details_for_Provided_Department.json`)

### Get Department Details for Provided Department  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/deps/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Department_Details_for_Provided_Department.json`)

### Get Departments  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/deps`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Departments.json`)

### Get Division Details for Provided Division  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/division/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Division_Details_for_Provided_Division.json`)

### Get Division Details for Provided Division  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/division/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Division_Details_for_Provided_Division.json`)

### Get Divisions  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/division`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Divisions.json`)

### Get Group for Provided Group  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/groups/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Group_for_Provided_Group.json`)

### Get Group for Provided Group  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/groups/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Group_for_Provided_Group.json`)

### Get Groups  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/groups`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Groups.json`)

### Get Merchandise Hierarchy for Omnichannel  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/merchhier`
- Params: `{'limit': 1}`
- Fields discovered: 15  (schema: `schema/Merchandise_Hierarchy_Get_Merchandise_Hierarchy_for_Omnichannel.json`)

### Get Subclass Details for Provided Subclass  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/subclass/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Subclass_Details_for_Provided_Subclass.json`)

### Get Subclass Details for Provided Subclass  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/subclass/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Subclass_Details_for_Provided_Subclass.json`)

### Get Subclasses  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/merchhier/subclass`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Merchandise_Hierarchy_Get_Subclasses.json`)

## Organizational Hierarchy

### Get Organizational Hierarchy Relationships  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/orghier`
- Params: `{'limit': 1}`
- Fields discovered: 16  (schema: `schema/Organizational_Hierarchy_Get_Organizational_Hierarchy_Relationships.json`)

### Get Organizational Hierarchy below Level for Omnichannel  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/orghier/descendant`
- Params: `{'limit': 1}`
- Fields discovered: 13  (schema: `schema/Organizational_Hierarchy_Get_Organizational_Hierarchy_below_Level_for_Omnichannel.json`)

### Get Organizational Hierarchy for Provided Level  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/orghier/:orgLevel`
- Params: `{'limit': 1}`
- Note: needs value(s) for path var(s): orgLevel

### Get Organizational Hierarchy for Provided Level and Hirerachy Identifier  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/orghier/:param1/:param2`
- Note: needs value(s) for path var(s): param1, param2

### Get Organizational Hirerachy  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/orghier`
- Params: `{'limit': 1}`
- Fields discovered: 18  (schema: `schema/Organizational_Hierarchy_Get_Organizational_Hirerachy.json`)

## Organizational Hierarchy - Stores

### Get Store Details  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/store`
- Params: `{'limit': 1}`
- Fields discovered: 115  (schema: `schema/Organizational_Hierarchy_Stores_Get_Store_Details.json`)

### Get Store Details for Omnichannel  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/location/retailstore`
- Params: `{'limit': 1}`
- Fields discovered: 29  (schema: `schema/Organizational_Hierarchy_Stores_Get_Store_Details_for_Omnichannel.json`)

### Get Store Details for Provided Store  —  `http_404`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/store/0`
- Preview: `{"status":"ERROR","message":"Resource not Found","error":{"status":404,"message":"Resource not Found"}}`
- Fields discovered: 5  (schema: `schema/Organizational_Hierarchy_Stores_Get_Store_Details_for_Provided_Store.json`)

### Get Store Details for Provided Store  —  `http_404`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/store/0`
- Preview: `{"status":"ERROR","message":"Resource not Found","error":{"status":404,"message":"Resource not Found"}}`
- Fields discovered: 5  (schema: `schema/Organizational_Hierarchy_Stores_Get_Store_Details_for_Provided_Store.json`)

## Organizational Hierarchy - Warehouses

### Get Warehouse Details  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/warehouse`
- Params: `{'limit': 1}`
- Fields discovered: 75  (schema: `schema/Organizational_Hierarchy_Warehouses_Get_Warehouse_Details.json`)

### Get Warehouse Details for Omnichannel  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/omnichannel/location/warehouse`
- Params: `{'limit': 1}`
- Fields discovered: 31  (schema: `schema/Organizational_Hierarchy_Warehouses_Get_Warehouse_Details_for_Omnichannel.json`)

### Get Warehouse Details for Provided Warehouse  —  `http_404`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/warehouse/0`
- Preview: `{"status":"ERROR","message":"Resource not Found","error":{"status":404,"message":"Resource not Found"}}`
- Fields discovered: 5  (schema: `schema/Organizational_Hierarchy_Warehouses_Get_Warehouse_Details_for_Provided_Warehouse.json`)

### Get Warehouse Details for Provided Warehouse  —  `http_404`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/foundation/warehouse/0`
- Preview: `{"status":"ERROR","message":"Resource not Found","error":{"status":404,"message":"Resource not Found"}}`
- Fields discovered: 5  (schema: `schema/Organizational_Hierarchy_Warehouses_Get_Warehouse_Details_for_Provided_Warehouse.json`)

## Purchase Orders

### Get Purchase Order Details  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/procurement/order`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Purchase_Orders_Get_Purchase_Order_Details.json`)

### Get Purchase Order Details by Order Number  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/procurement/order/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Purchase_Orders_Get_Purchase_Order_Details_by_Order_Number.json`)

### Get Purchase Order Details by Order Number  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/procurement/order/0`
- Preview: `{"status":"ERROR","message":"API is not enabled. Use the webservice configuration screen to initiate the enablement process and then run the merchapi data refresh batch job to complete the initial data load.","error":{"status":400,"message":"API is not enabled. Use the webservice configuration scree`
- Fields discovered: 5  (schema: `schema/Purchase_Orders_Get_Purchase_Order_Details_by_Order_Number.json`)

## Sales

### Get Item Location Weekly Sales  —  `http_400`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/sales/itemLocation/weekly`
- Params: `{'limit': 1}`
- Preview: `{"status":"ERROR","message":"Atleast one of the following query parameter should be provided - eowDate, location, item.","error":{"status":400,"message":"Atleast one of the following query parameter should be provided - eowDate, location, item."}}`
- Fields discovered: 5  (schema: `schema/Sales_Get_Item_Location_Weekly_Sales.json`)

## Untagged

### getExternalGrammar  —  `skipped_needs_id`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/application.wadl/:path`
- Note: needs value(s) for path var(s): path

### getStatus  —  `ok`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services`
- Fields discovered: 24  (schema: `schema/Untagged_getStatus.json`)

### getWadl  —  `http_406`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/application.wadl`
- Preview: `<!doctype html><html lang="en"><head><title>HTTP Status 406 – Not Acceptable</title><style type="text/css">body {font-family:Tahoma,Arial,sans-serif;} h1, h2, h3, b {color:white;background-color:#525D76;} h1 {font-size:22px;} h2 {font-size:16px;} h3 {font-size:14px;} p {font-size:12px;} a {color:bla`

### ping  —  `http_204`
- URL: `https://rex.retail.us-ashburn-1.ocs.oraclecloud.com/rgbu-rex-hibb-prd1-mfcs/MerchIntegrations/services/ping`
